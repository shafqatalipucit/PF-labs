#include <iostream>
using namespace std;
int main()
{
    int n=0;
    cout<<"Input the value of N:"<<"\n";
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"*"<<"\n";
        for(int j=0;j<=i;j++)
        {
            cout<<" ";
        }
    }
    
     for(int i=n;i>=0;i--)
    {
        cout<<"*"<<"\n";
        for(int j=0;j<=i;j++)
        {
            cout<<" ";
        }
    }
    for(int i=0;i<n;i++)
    {
        cout<<"*"<<"\n";
        for(int j=0;j<=i;j++)
        {
            cout<<" ";
        }
    }
    
     for(int i=n;i>=0;i--)
    {
        cout<<"*"<<"\n";
        for(int j=0;j<=i;j++)
        {
            cout<<" ";
        }
    }
    return 0;
}