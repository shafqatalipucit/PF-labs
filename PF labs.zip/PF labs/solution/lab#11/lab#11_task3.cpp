#include <iostream>
using namespace std;
int main()
{
    int n = 0, k = 0, j = 0;
    cout << "Input the value of N:"
         << "\n";
    cin >> n;
    cout << "Input the value of K:"
         << "\n";
    cin >> k;

    for (int z = 0; z < k; z++)
    {
        cout << "{";
        for (int i = 0; i < n; i++)
        {

            cout << "("
                 << " ";
            for (j = 0; j <= i; j++)
            {

                cout << j ;
                if(j!=i)
                {
                cout<< " ,";
                }
            }

            cout << ")"
            
                 << " ";

            if (i == n - 1)
            {
                continue;
            }
            cout << ",";
        }
        if(j!=n-1)
        {
              cout << "}";
        cout << "\n";}
      
    }
    return 0;
}