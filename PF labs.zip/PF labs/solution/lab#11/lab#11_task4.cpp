#include <iostream>
using namespace std;

int main() {
    int N = 0;
    cout << "Enter number: ";
    cin >> N;
    cout << "Factors of " << N << " are: ";

    // Loop to find factors
    for (int i = 1; i <= N; i++) {
        if (N % i == 0) {
            cout << i << " ";
        }
    }

    // Checking for primality
    int factorCount = 0;
    for (int i = 1; i <= N; i++) {
        if (N % i == 0) {
            factorCount++;
        }
    }

    if (factorCount == 2) {
        cout << "\n" << N << " is a prime number." << endl;
    } else {
        cout << "\n" << N << " is not a prime number." << endl;
    }

    return 0;
}
