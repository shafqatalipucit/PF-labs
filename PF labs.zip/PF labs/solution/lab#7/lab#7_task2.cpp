#include <iostream>
using namespace std;

int main() {
    int team1_runs, team1_wickets, team2_runs, team2_wickets;

    // Input for Team 1
    cout << "Enter runs scored by Team 1: ";
    cin >> team1_runs;
    cout << "Enter wickets lost by Team 1: ";
    cin >> team1_wickets;

    // Input for Team 2
    cout << "Enter runs scored by Team 2: ";
    cin >> team2_runs;
    cout << "Enter wickets lost by Team 2: ";
    cin >> team2_wickets;

    // Check for non-negative runs and wickets
    if (team1_runs < 0 || team1_wickets < 0 || team2_runs < 0 || team2_wickets < 0) {
        cout << "Invalid input: Runs and wickets must be non-negative." << endl;
        return 1;
    }

    // Check if Team 2 has more runs and fewer wickets
    if (team2_runs > team1_runs && team2_wickets < 10) {
        cout << "Team 2 has won by " << 10 - team2_wickets << " wickets." << endl;
    }
    // Check if Team 1 has more runs
    else if (team1_runs > team2_runs) {
        cout << "Team 1 has won by " << team1_runs - team2_runs << " runs." << endl;
    }
    // Check if both teams have the same runs but different wickets
    else if (team1_runs == team2_runs && team1_wickets != team2_wickets) {
        if (team1_wickets < team2_wickets) {
            cout << "Team 1 won by 1 run." << endl;
        } else {
            cout << "Team 2 has won by " << 10 - team2_wickets << " wickets." << endl;
        }
    }
    // If none of the above conditions are met, it's a draw
    else {
        cout << "The match is a draw." << endl;
    }

    return 0;
}
