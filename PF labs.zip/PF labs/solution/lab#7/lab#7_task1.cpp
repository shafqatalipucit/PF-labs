#include <iostream>
#include <cmath> // Use <cmath> instead of <math.h>

using namespace std;

int main()
{
    int a, b, c, discriminant, root1, root2;
    
    do
    {
        cout << "Enter the value of a: ";
        cin >> a;
        
        if (a <= 0)
        {
            cout << "Please enter a value of 'a' greater than 0." << endl;
        }
    } while (a <= 0);

    cout << "Enter the value of b: ";
    cin >> b;

    cout << "Enter the value of c: ";
    cin >> c;

    discriminant = (b * b - 4 * a * c);

    if (discriminant < 0)
    {
        cout << "Sorry, roots are imaginary." << endl;
    }
    else if (discriminant == 0)
    {
        root1 = -b / (2 * a);
        root2 = -b / (2 * a);
        cout << "root1: " << root1 << endl;
        cout << "root2: " << root2 << endl;
    }
    else
    {
        root1 = (-b + sqrt(discriminant)) / (2 * a);
        root2 = (-b - sqrt(discriminant)) / (2 * a);
        cout << "root1: " << root1 << endl;
        cout << "root2: " << root2 << endl;
    }

    return 0;
}
