#include <iostream>
#include <cstdlib> // Include the library for rand() and srand()
#include <ctime>   // Include the library for time()

using namespace std;

int main() {
    srand(time(NULL)); // Seed the random number generator using the current time

    int Random_numbers[4], count = 1;

    // Generate random numbers between 1 and 5 and store them in the array
    for (int i = 0; i < 4; i++) {
        Random_numbers[i] = rand() % 5 + 1; // Generates a number between 1 and 5 (inclusive)
    }

    cout << Random_numbers[0] << "\t" << Random_numbers[1] << "\t" << Random_numbers[2] << "\t" << Random_numbers[3] << "\n";

    // Check if there are any duplicates
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 4; j++) {
            if (Random_numbers[i] == Random_numbers[j]) {
                count++;
            }
        }
    }

    if (count > 0) {
        cout  << 4 - count << " numbers are different." << "\n";
    } else {
        cout << "All numbers are different." << "\n";
    }

    cout << "-------------------------------------" << "\n";

    return 0;
}
