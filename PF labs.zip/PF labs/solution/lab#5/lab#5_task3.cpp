#include <iostream>
#include <random>
using namespace std;
int main()
{
    int First_operand, Second_operand, choice, sum, difference, product;
    First_operand = (rand()%9+1);
    Second_operand = (rand()%9+1);
    cout << "You entered:"
         << "\t" << First_operand << "\t" << Second_operand << "\n";

    cout << "Enter the choice  between 1 and 3 , 1 for sum 2 for difference and 3 for product:"
         << "\n";
    cin >> choice;

    if (choice == 1)
    {
        cout << "Enter the sum of the operand:"
             << "\n";
        cin >> sum;
        if (sum == (First_operand + Second_operand))
        {
            cout << "Correct "
                 << "\n";
        }
        else
        {
            cout << "Incorrect"
                 << "\n";
        }
    }

    else if (choice == 2)
    {
        cout << "Enter the difference of the operand:"
             << "\n";
        cin >> difference;
        if (difference == (First_operand - Second_operand))
        {
            cout << "Correct "
                 << "\n";
        }
        else
        {
            cout << "Incorrect"
                 << "\n";
        }
    }

    else if (choice == 3)
    {
        cout << "Enter the product of the operand:"
             << "\n";
        cin >> product;
        if (product == (First_operand * Second_operand))
        {
            cout << "Correct "
                 << "\n";
        }
        else
        {
            cout << "Incorrect"
                 << "\n";
        }
    }
    else
    {
        cout << "Enter a valid option between 1 and  3:"
             << "\n";
    }
    return 0;
}