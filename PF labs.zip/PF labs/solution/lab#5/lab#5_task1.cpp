#include <iostream>
#include <iomanip>

using namespace std;

// Function to calculate percentage
pair<int, int> calculatePercentage(int males, int females) {
    int totalStudents = males + females;
    int malePercentage = (males * 100) / totalStudents;
    int femalePercentage = (females * 100) / totalStudents;
    return make_pair(malePercentage, femalePercentage);
}

// Function to display output
void displayOutput(int malePercentage, int femalePercentage) {
    if (malePercentage > femalePercentage) {
        cout << "============================" << endl;
        cout << "| Percentage of Males: " << malePercentage << " |" << endl;
        cout << "| Percentage of Females: " << femalePercentage << " |" << endl;
        cout << "============================" << endl;
    } else {
        cout << "********************************" << endl;
        cout << "*** Percentage of Females: " << femalePercentage << " % ***" << endl;
        cout << "*** Percentage of Males: " << malePercentage << " % ***" << endl;
        cout << "********************************" << endl;
    }
}

// Main function
int main() {
    int males, females;
    cout << "Enter Number of Males: ";
    cin >> males;
    cout << "Enter Number of Females: ";
    cin >> females;
    
    pair<int, int> percentages = calculatePercentage(males, females);
    displayOutput(percentages.first, percentages.second);

    return 0;
}
