#include <iostream>
#include <string>
using namespace std;
 string units[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
  string teens[]={"ten","eleven","twelve","thirteen","fouteen","fifteen","sixteen","seventeen","eighteen","nineteen"};

string NumberToWords(int num)
{
    if(num<10)
    {
        return units[num];
    }
    else if((num>=10) && (num<20)){
        return teens[num];
    }
}
int main()
{
 int a;
 cout<<"Enter a number:"<<"\n";
 cin>>a;
 string b=NumberToWords(a);
 cout<< a <<"\t"<<"In english is:"<<"\t"<<b;
    return 0;
}
