#include <iostream>
using namespace std;
int main()
{
    int Amount_deposited;

    cout << "Enter the amount you want to deposit:"
         << "\n";
    cin >> Amount_deposited;
    cout << "Amount deposited:"<<Amount_deposited
         << "\n";

    if (Amount_deposited == 0)
    {
        cout << "Please Enter  amount greater than 0"
             << "\n";
    }

    else if (Amount_deposited < 500000)
    {
        int Amount_After_OneYear = Amount_deposited * 1.07;
        cout << "Amount after one  year:" << Amount_After_OneYear << "\n";

        int Amount_After_TwoYear = Amount_After_OneYear * 1.07;
        cout << "Amount after Two  year:" << Amount_After_TwoYear << "\n";

        int Amount_After_ThreeYear = Amount_After_TwoYear * 1.07;
        cout << "Amount after Three  year:" << Amount_After_ThreeYear << "\n";
    }

    else
    {
        int Amount_After_OneYear = Amount_deposited * 1.10;
        cout << "Amount after one  year:" << Amount_After_OneYear << "\n";

        int Amount_After_TwoYear = Amount_After_OneYear * 1.10;
        cout << "Amount after Two  year:" << Amount_After_TwoYear << "\n";

        int Amount_After_ThreeYear = Amount_After_TwoYear * 1.10;
        cout << "Amount after Three  year:" << Amount_After_ThreeYear << "\n";
    }

    return 0;
}