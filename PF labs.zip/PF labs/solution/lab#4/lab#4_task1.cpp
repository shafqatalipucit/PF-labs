#include <iostream>
using namespace std;
int main()
{
    int net_salary, Basic_salary, Medical_allowance, conveyance_allowance,House_rent,Gross_salary,Tax,Annual_Gross;

    cout << "Enter amount of basic salary:"
         << "\n";
    cin >> Basic_salary;
    cout<<"--------------------------------------"<<"\n"<<"\n"<<"\n"<<"\n";
    cout << "Basic Salary:"
         << "\t" << Basic_salary << "\n";

    Medical_allowance = Basic_salary * 0.1;
    cout << "Medecal Allowence:"
         << "\t" << Medical_allowance << "\n";

    conveyance_allowance = Basic_salary * 0.15;
    cout << "conveyance Allowence:"
         << "\t" << conveyance_allowance << "\n";

    House_rent= Basic_salary * .45;
cout << "House_rent:"
         << "\t" << House_rent << "\n""\n""\n""\n";
         cout<<"-----------------------------------------"<<"\n";

Gross_salary=Basic_salary+Medical_allowance+conveyance_allowance+House_rent;
//cout << "Gross_salary:"
  //       << "\t" << Gross_salary << "\n";
Annual_Gross=Gross_salary*12;

if(Annual_Gross<=200000)
{
    Tax=0;
    cout << "Gross_salary:"
         << "\t" << Gross_salary<< "\n";

         cout << "Tax:"
         << "\t" << Tax<< "\n";
}
else if((Annual_Gross>200000) && (Gross_salary<=400000))
{
    Tax=(Gross_salary*.10);
    cout << "Gross salary:"
         << "\t" << Gross_salary<< "\n";

         cout << "Tax:"
         << "\t" <<Tax << "\n";

}
else if((Annual_Gross>400000) && (Gross_salary<=600000))

{
    Tax=(Gross_salary*.15);
    cout << "Gross_salary:"
         << "\t" << Gross_salary<< "\n";

         cout << "Tax:"
         << "\t" <<Tax << "\n";
}
else if((Annual_Gross>600000) && (Gross_salary<=800000))
{
    Tax=(Gross_salary*.20);
    cout << "Gross_salary:"
         << "\t" << Gross_salary<< "\n";

         cout << "Tax:"
         << "\t" <<Tax << "\n"; 
}
else
{
    Tax=Gross_salary*.25;
    cout << "Gorss_salary:"
         << "\t" << Gross_salary<< "\n";

         cout << "Tax:"
         << "\t" <<Tax << "\n";
         
}
cout<<"----------------------------------------------"<<"\n";
net_salary=Gross_salary-Tax;
 cout << "net_salary:"
         << "\t" << net_salary<< "\n";

    return 0;
}