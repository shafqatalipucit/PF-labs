#include <iostream>
#include <math.h>
using namespace std;
void differenceN()
{
    int A[10];
    for (int i = 0; i < 10; i++)
    {
        cout << "Number:"<<i+1 
             << "\n";
        cin >> A[i];
        if(i>0)
        {
           int  difference=A[i]-A[i-1];
            cout<<"Difference:"<<difference<<"\n";
        }
        
    }
}

int main()
{
    differenceN();
    return 0;
}
