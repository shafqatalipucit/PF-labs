#include<iostream>
#include<math.h>
using namespace std;


void print(int starting,int ending)
{
    cout<<"In Accending order:"<<"\n";
    cout<<"-----------------------------------------------"<<"\n";
    for(int i=starting;i<ending;i++)
    {
        cout<<i<<"\t";


    }
    cout<<"\n";
    cout<<"In Deccending order:"<<"\n";
    cout<<"-----------------------------------------------"<<"\n";
    for(int i=ending;i>starting;i--)
    {
        cout<<i<<"\t";

    }
    cout<<"\n";

    cout<<"square  of the numbers :"<<"\n";
    cout<<"-----------------------------------------------"<<"\n";
     for(int i=starting;i<ending;i++)
    {
        cout<<pow(i,2)<<"\t";


    }
    cout<<"\n";

    cout<<"cube  of the numbers :"<<"\n";
    cout<<"-----------------------------------------------"<<"\n";
     for(int i=starting;i<ending;i++)
    {
        cout<<pow(i,3)<<"\t";


    }


}

int main ()
{
    print(3,10);
  return 0;

} 
