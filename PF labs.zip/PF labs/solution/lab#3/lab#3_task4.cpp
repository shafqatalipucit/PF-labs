// Difference between the character variables
#include <iostream>
using namespace std;
int main()
{
    char FirstCharacter, SecondCharacter, ThirdCharacter;
    cout << "Enter First character:"
         << "\n";
    cin >> FirstCharacter;
    cout << "Enter Second character:"
         << "\n";
    cin >> SecondCharacter;
    cout << "Enter third character:"
         << "\n";
    cin >> ThirdCharacter;
    cout << "Difference between"
         << "\t" << FirstCharacter << "\t"
         << "and "
         << "\t" << SecondCharacter << "\t"
         << "is:"
         << "\t" << FirstCharacter - SecondCharacter << "\n";
    cout << "Difference between"
         << "\t" << SecondCharacter << "\t"
         << "and "
         << "\t" << ThirdCharacter << "\t"
         << "is:"
         << "\t" << SecondCharacter - ThirdCharacter << "\n";

    cout << "Difference between"
         << "\t" << ThirdCharacter << "\t"
         << "and "
         << "\t" << FirstCharacter << "\t"
         << "is:"
         << "\t" << ThirdCharacter - FirstCharacter << "\n";

    return 0;
}