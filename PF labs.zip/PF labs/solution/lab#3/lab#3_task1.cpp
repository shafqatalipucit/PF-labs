// program to convert centigrade into fahrenheit
#include <iostream>
using namespace std;
int main()
{
    float Centigrade, fahrenheit;
    cout << "Enter the temperature in centigrade:"
         << "\n";
    cin >> Centigrade;
    fahrenheit = Centigrade * 9/5 + 32;
    cout << "Temperature in fahrenheit:" << fahrenheit << "\n";
    return 0;
}