// program to parimeters of 5 sided shape
#include <iostream>
#include<math.h>
using namespace std;
int main()
{
    int x1, x2, Answer;
    cout << "x1:"
         << "\n";
    cin >> x1;

    cout << "x2:"
         << "\n";
    cin >> x2;

    Answer=pow(x1,2)+pow(x2,2)+2*(x1*x2);
    cout<<"(x1)^2+(x2)^2+2x1x2="<<Answer<<"\n";

    Answer=pow(x1,2)+1/pow(x2,2)-2;
    cout<<"(x1)^2+1/(x2)^2-2="<<Answer<<"\n";

    Answer=(x1+x2)*(x1-x2);
    cout<<"(x1+x2)*(x1-x2):"<<Answer<<"\n";

    return 0;
}