// program to parimeters of 5 sided shape
#include <iostream>
using namespace std;
int main()
{
    int side1, side2, side3, side4, side5, perimeter;
    cout << "Side1:"
         << "\n";
    cin >> side1;

    cout << "Side2:"
         << "\n";
    cin >> side2;
    cout << "Side3:"
         << "\n";
    cin >> side3;
    cout << "Side4:"
         << "\n";
    cin >> side4;
    cout << "Side5:"
         << "\n";
    cin >> side5;

    perimeter = side1 + side2 + side3 + side4 + side5;
    cout << "Perimeter of the shape is :" << perimeter << "\n";
    return 0;
}