#include<iostream>
using namespace std;
void print_char(const char c, const int n)
{
    for(int i=0;i<n ;i++)
    {
        cout<<c;
    }
}
int main()
{
    print_char('a',5);
    
    return 0;
}