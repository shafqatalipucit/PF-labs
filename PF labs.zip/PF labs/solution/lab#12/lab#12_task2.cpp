#include <iostream>
using namespace std;
int isPrime(const int n)
{
    bool isprime = true;
    for (int i = 2; i < n; i++)
    {

        if (n % i == 0)
        {
            isprime = false;
            return 0;
        }
    }
    return isprime ? 1 : 0;
}
void printPrime(const int n)
{
    for (int j = 2; j <= n; j++)
    {
        int a = isPrime(j);
        if (a == 1)
        {
            cout << j << "\t";
        }
    }
}
int main()
{
    // int a=isPrime(7);
    // cout<<a;
    printPrime(50);
    return 0;
}