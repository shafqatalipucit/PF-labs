#include <iostream>
using namespace std;

void print_N(const int height) {
    if (height < 2) {
        cout << "Height must be at least 2 for N." << endl;
        return;
    }

    for (int i = 0; i < height; ++i) {
        cout << "*";

        // Printing spaces between the first and last stars of the N
        for (int j = 0; j < height - 2; ++j) {
            if (i == j || i + j == height - 1) {
                cout << "*";
            } else {
                cout << " ";
            }
        }

        // Printing the last star of the N
        if (i != height - 1) {
            cout << "*";
        }

        cout << endl;
    }
}

int main() {
    int N_height = 5; // Height of the N
    print_N(N_height);
    return 0;
}
