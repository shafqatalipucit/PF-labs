#include <iostream>
#include <random>

using namespace std;
int main()
{
    int Numbers[3], smaller, larger;
    for (int i = 0; i < 3; i++)
    {
        Numbers[i] = (rand()%5+1);
        cout << Numbers[i] << "\n";
    }
    smaller = Numbers[0];
    larger = Numbers[0];

    if ((Numbers[0] == Numbers[1]) && (Numbers[0] == Numbers[2]))
    {
        cout << "All numbers are equal."
             << "\n";
    }
    if ((Numbers[0] != Numbers[1]) && (Numbers[0] != Numbers[2]))
    {
        cout << "All numbers are different."
             << "\n";
    }

    for (int i = 0; i < 3; i++)
    {
        if (Numbers[i + 1] < smaller)
        {
            smaller = Numbers[i + 1];
        }
    }
    for (int i = 0; i < 3; i++)
    {
        if (Numbers[i + 1] > larger)
        {
            larger = Numbers[i + 1];
        }
    }
    cout << "Smaller is :" << smaller << "\n";
    cout << "larger is :" << larger << "\n";

    if (((Numbers[2] > smaller) && (Numbers[2] < Numbers[1])) || ((Numbers[2] < smaller) && (Numbers[2] > Numbers[1])))
    {
        cout << "Third element  is  in middle position:"
             << "\n";
    }
    if (((Numbers[2] < smaller) && (Numbers[1] > smaller)) || ((Numbers[2] > smaller) && (Numbers[1] < smaller)))
    {
        cout << "first element  is  in middle position:"
             << "\n";
    }
    cout << "-----------------------------------"
         << "\n";

    return 0;
}