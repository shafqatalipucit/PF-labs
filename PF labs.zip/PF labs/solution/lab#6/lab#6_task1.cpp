#include <iostream>
#include<math.h>
using namespace std;
int main()
{
 cout<<"-----------------------------------"<<"\n";
 int numbers[4],average,sum=0;
 
 for (int i=0;i<4;i++)
 {
    cout<<"Number :"<<i+1<<"\n";
    cin>>numbers[i];
    sum=sum+numbers[i];
 }
 average=sum/4;
  cout<<"Average"<<"\t"<<average<<"\n";

 for(int i=0;i<4;i++)
 {
    if(numbers[i]<average)
    {
        cout<<i+1<<"th element is smaller than average"<<"\n";
    }
    else{
                cout<<i+1<<"th element is larger than average"<<"\n";

    }
 }
 


    return 0;
}