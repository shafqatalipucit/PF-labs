#include <iostream>
#include <random>

using namespace std;
int main()
{
    int choice[3];
    for (int i = 0; i < 3; i++)
    {
        cout << "Enter number for "<<"  " << i + 1 <<" "<< "roll"
             << "\n";
        cin >> choice[i];
    }
    if ((choice[0] == choice[1]) && (choice[0] == choice[2]))
    {
        cout << choice[0] << " "<<"Appears  three times"
             << "\n";
    }
    else if  ((choice[1] == choice[0]) && (choice[1] == choice[2]))
    {
        cout << choice[1] <<" " <<"Appears  three times"
             << "\n";
    }
    else if ((choice[2] == choice[1]) && (choice[2] == choice[0]))
    {
        cout << choice[2] << " " <<"Appears  three times"
             << "\n";
    }

   else if ((choice[0] == choice[1]) || (choice[0] == choice[2]))
    {
        cout << choice[0] <<" "<< "Appears  two  times"
             << "\n";
    }
    else if ((choice[1] == choice[0]) || (choice[1] == choice[2]))
    {
        cout << choice[1] <<" "<< "Appears  two times"
             << "\n";
    }
    else{
        cout<<"All the entered enteries are different"<<"\n";
    }
    
    return 0;
}