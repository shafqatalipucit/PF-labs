#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

int main() {
    srand(time(0)); // Seed for random number generation

    const int numStudents = 30;
    int midterms[numStudents], finals[numStudents], sessionals[numStudents];
    char grades[numStudents];
    int totalMarks[numStudents];

    int totalPass = 0;
    int totalMarksSum = 0;
    int midtermSum = 0, finalSum = 0, sessionalSum = 0;
    int maxMarks = 0, maxMidterm = 0, maxFinal = 0, maxSessional = 0;
    int minMarks = INT_MAX, minMidterm = INT_MAX, minFinal = INT_MAX, minSessional = INT_MAX;

    cout << "Roll No\tMidterm\tFinal\tSessional\tTotal\tGrade" << endl;

    for (int i = 0; i < numStudents; ++i) {
        int rollNo = i + 1;
        midterms[i] = rand() % 36; // Random midterm marks out of 35
        finals[i] = rand() % 41;   // Random final term marks out of 40
        sessionals[i] = rand() % 26; // Random sessional marks out of 25

        totalMarks[i] = midterms[i] + finals[i] + sessionals[i];
        totalMarksSum += totalMarks[i];

        if (totalMarks[i] > maxMarks) maxMarks = totalMarks[i];
        if (midterms[i] > maxMidterm) maxMidterm = midterms[i];
        if (finals[i] > maxFinal) maxFinal = finals[i];
        if (sessionals[i] > maxSessional) maxSessional = sessionals[i];

        if (totalMarks[i] < minMarks) minMarks = totalMarks[i];
        if (midterms[i] < minMidterm) minMidterm = midterms[i];
        if (finals[i] < minFinal) minFinal = finals[i];
        if (sessionals[i] < minSessional) minSessional = sessionals[i];

        if (totalMarks[i] >= 50) {
            grades[i] = (totalMarks[i] >= 80) ? 'A' : ((totalMarks[i] >= 70) ? 'B' : 'C');
            totalPass++;
        } else {
            grades[i] = 'F';
        }

        cout << rollNo << "\t" << midterms[i] << "\t" << finals[i] << "\t" << sessionals[i] << "\t\t" << totalMarks[i] << "\t" << grades[i] << endl;

        midtermSum += midterms[i];
        finalSum += finals[i];
        sessionalSum += sessionals[i];
    }

    double overallAvgMarks = static_cast<double>(totalMarksSum) / numStudents;
    double avgMidterm = static_cast<double>(midtermSum) / numStudents;
    double avgFinal = static_cast<double>(finalSum) / numStudents;
    double avgSessional = static_cast<double>(sessionalSum) / numStudents;

    cout << "Total: " << numStudents << endl;
    cout << "Pass: " << totalPass << endl;
    cout << "Fail: " << numStudents - totalPass << endl;
    cout << "Overall Average Marks: " << fixed << setprecision(1) << overallAvgMarks << endl;
    cout << "Average Midterm Marks: " << avgMidterm << endl;
    cout << "Average Sessional Marks: " << avgSessional << endl;
    cout << "Average Final term Marks: " << avgFinal << endl;
    cout << "Maximum Marks: " << maxMarks << endl;
    cout << "Maximum Midterm Marks: " << maxMidterm << endl;
    cout << "Maximum Sessional Marks: " << maxSessional << endl;
    cout << "Maximum Final term Marks: " << maxFinal << endl;
    cout << "Minimum Marks: " << minMarks << endl;
    cout << "Minimum Midterm Marks: " << minMidterm << endl;
    cout << "Minimum Sessional Marks: " << minSessional << endl;
    cout << "Minimum Final term Marks: " << minFinal << endl;

    return 0;
}
