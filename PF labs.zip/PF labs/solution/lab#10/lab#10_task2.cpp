#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    string counting ={'one' , 'two' ,'three' , 'four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty','twenty','twentyone','twentytwo','twentythree','twentyfour','twentyfive','twentysix','twentyseven','twentyeight','twentynine','thirty','thirtyone','thirtytwo','thirtythree','thirtyfour','thirtyfive','thirtysix','thirtyseven','thirtyeight','thirtynine','fourty','fourtyone','fourtytwo','fourtythree','fourtyfour','fourtyfive','fourtysix','fourtyseven','fourtyeight','fourtynine','fifty','fiftyone','fiftytwo','fiftythree','fiftyfour','fiftyfive','fiftysix','fiftyseven','fiftyeight','fiftynine','sixty'};
     int i=0;
    for(int i=0;i<100;i++)
    {
        if(i<10)
        {
        cout<<"["<<i<<"]"<<"\t";

        }
        else{
        cout<<"["<<i<<"\t"<<(i%10)+trunc(i/10)<<"]"<<"\t";
        }
    }
    return 0;
}