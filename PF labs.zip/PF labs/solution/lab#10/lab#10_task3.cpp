#include <iostream>
#include <math.h>
#include <random>
using namespace std;
int main()
{
    int sum = 0;
    int product = 1;
    int difference = 0;
    int score = 0;
    int N1 = rand() % 9 + 1;
    int N2 = rand() % 9 + 1;
    cout << "what is sum of two numbers:"
         << "\n";
    cin >> sum;
    if (sum != (N1 + N2))
    {

        cout << "what is product of two numbers:"
             << "\n";
        cin >> product;
        cout << "what is difference of two numbers:"
             << "\n";
        cin >> difference;
    }
    else
    {
        score = score + 10;
    }

    if (difference == (N1 - N2))
    {
        score = score + 10;
    }
    if (product == (N1 * N2))
    {
        score = score + 10;
    }
    cout << "You earned total score:" << score << "\n";
    return 0;
}