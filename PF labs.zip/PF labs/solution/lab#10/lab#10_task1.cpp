#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int i=0;
    for(int i=0;i<100;i++)
    {
        if(i<10)
        {
        cout<<"["<<i<<"]"<<"\t";

        }
        else{
        cout<<"["<<i<<"\t"<<(i%10)+trunc(i/10)<<"]"<<"\t";
        }
    }
    return 0;
}